<?php
/**
 * Webalive functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package webalive
 */

if ( ! function_exists( 'webalive_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function webalive_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Webalive, use a find and replace
		 * to change 'webalive' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'webalive', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'primary' => esc_html__( 'Primary', 'webalive' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'webalive_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );

		/**
		 * Add Post Format Support
		 */
		add_theme_support( 'post-formats', array( 
			'audio',
			'aside', 
			'gallery', 
			'image',
			'link',
			'video',
		) );

		/**
		 * WooCommerce Support
		 */
		add_theme_support( 'woocommerce' );
	}
endif;
add_action( 'after_setup_theme', 'webalive_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function webalive_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'webalive_content_width', 640 );
}
add_action( 'after_setup_theme', 'webalive_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function webalive_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'webalive' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	// Footer Widget 1
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 1', 'webalive' ),
		'id'            => 'footer-widget-1',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	// Footer Widget 2
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 2', 'webalive' ),
		'id'            => 'footer-widget-2',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	// Footer Widget 3
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 3', 'webalive' ),
		'id'            => 'footer-widget-3',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	// Footer Widget 4
	register_sidebar( array(
		'name'          => esc_html__( 'Footer Widget 4', 'webalive' ),
		'id'            => 'footer-widget-4',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-footer-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	// Copyright Widget 1
	register_sidebar( array(
		'name'          => esc_html__( 'Copyright Widget 1', 'webalive' ),
		'id'            => 'copyright-widget-1',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-copyright-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
	// Copyright Widget 2
	register_sidebar( array(
		'name'          => esc_html__( 'Copyright Widget 2', 'webalive' ),
		'id'            => 'copyright-widget-2',
		'description'   => esc_html__( 'Add widgets here.', 'webalive' ),
		'before_widget' => '<div id="%1$s" class="widget webalive-copyright-widget %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<h4 class="widget-title">',
		'after_title'   => '</h4>',
	) );
}
add_action( 'widgets_init', 'webalive_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function webalive_public_scripts() {
	wp_enqueue_style( 'webalive-style', get_stylesheet_uri() );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
	wp_enqueue_style( 'webalive', get_template_directory_uri() . '/assets/css/theme.css' );

	wp_enqueue_script( 'webalive-navigation', get_template_directory_uri() . '/assets/js/navigation.js', array(), '20151215', true );
	wp_enqueue_script( 'webalive-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20151215', true );
	wp_enqueue_script( 'popper', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), '20180708', true );
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('popper'), '20180708', true );
	wp_enqueue_script( 'webalive', get_template_directory_uri() . '/assets/js/theme.js', array('jquery'), '20180708', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'webalive_public_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Bootstrap 4 Navwalkers
 */
require get_template_directory() . '/navwalkers.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce/webalive-woocommerce.php';
	require get_template_directory() . '/inc/woocommerce/webalive-woocommerce-template-hooks.php';
	require get_template_directory() . '/inc/woocommerce/webalive-woocommerce-functions.php';
}

/**
 * TGM Plugin Activation
 */
require get_template_directory() . '/inc/plugins/tgm-plugin-activation.php';


/**
 * Change the defualt WP login logo
 */
function webalive_login_screen_logo() {
	echo '<style type="text/css">
	.login h1 a {background-image: url('.get_bloginfo( 'template_directory' ).'/assets/img/login-screen.png) !important; height: auto !important; }
	</style>';
}
add_action( 'login_head', 'webalive_login_screen_logo' );

function webalive_login_head_url( $url ) {
	return get_bloginfo( 'url' );
}
add_filter( 'login_headerurl', 'webalive_login_head_url' );

/**
 * A function that contains all options value
 */
function webalive_theme_options() {
	return $webalive_options = array(
		'webalive_header_type' => 'default', // Options: default, large, minimal, none
	);
}












// This code create custom post type
function easytuts_eventposts_post() {
  $labels = array(
    'name'               => _x( 'Eventposts', 'post type general name' ),
    'singular_name'      => _x( 'Eventpost', 'post type singular name' ),
    'add_new'            => _x( 'Add New', 'eventpost' ),
    'add_new_item'       => __( 'Add New Eventpost' ),
    'edit_item'          => __( 'Edit Eventpost' ),
    'new_item'           => __( 'New Eventpost' ),
    'all_items'          => __( 'All Eventposts' ),
    'view_item'          => __( 'View Eventpost' ),
    'search_items'       => __( 'Search Eventposts' ),
    'not_found'          => __( 'No eventpost found' ),
    'not_found_in_trash' => __( 'No eventpost found in the Trash' ), 
    'parent_item_colon'  => '',
    'menu_name'          => 'EventPosts'
  );
  $args = array(
    'labels'        => $labels,
    'description'   => 'Holds eventposts and eventpost specific data',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor','taxonomies', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true,
  );
  register_post_type( 'eventposts', $args ); 
}
add_action( 'init', 'easytuts_eventposts_post' );
// end--This code create custom post type


// This code create Categories under custom post type
function easytuts_taxonomies_eventposts_posttype() {
  $labels = array(
    'name'              => _x( 'Eventposts Categories', 'taxonomy general name' ),
    'singular_name'     => _x( 'Eventpost Category', 'taxonomy singular name' ),
    'search_items'      => __( 'Search Eventpost Categories' ),
    'all_items'         => __( 'All Eventposts Categories' ),
    'parent_item'       => __( 'Parent Eventpost Category' ),
    'parent_item_colon' => __( 'Parent Eventpost Category:' ),
    'edit_item'         => __( 'Edit Eventpost Category' ), 
    'update_item'       => __( 'Update Eventpost Category' ),
    'add_new_item'      => __( 'Add New Eventpost Category' ),
    'new_item_name'     => __( 'New Eventpost Category' ),
    'menu_name'         => __( 'Eventpost Categories' ),
  );
  $args = array(
    'labels' => $labels,
    'hierarchical' => true,
  );
  register_taxonomy( 'leagues', 'eventposts', $args );
}
add_action( 'init', 'easytuts_taxonomies_eventposts_posttype', 0 );
// end--This code create Categories under custom post type

// This code check is there same title exist and insert post into custom post type. Also call Generate_Featured_Image function
function easytuts_taxonomies_eventposts() {

    $postTitle = 'post 33333';
    global $wpdb;

    $query = $wpdb->prepare(
        'SELECT ID FROM ' . $wpdb->posts . '
        WHERE post_title = %s
        AND post_type = \'eventposts\'',
        $postTitle
    );
    $wpdb->query( $query );

    if ( $wpdb->num_rows ) {
        $post_id = $wpdb->get_var( $query );
        $meta = get_post_meta( $post_id, 'eventposts', TRUE );
        $meta++;
        update_post_meta( $post_id, 'eventposts', $meta );
    } 

	else{

		$my_post = array(
		     'post_title'   => $postTitle,
		     // 'post_date'    => 12-12-21,
		     'post_content' => 'This is my post content.',
		     'post_status'  => 'publish',
		     'post_type'    => 'eventposts',
		     'post_excerpt' => 'This is my post excerpt.',
		  );

		$post_id = wp_insert_post($my_post);


		Generate_Featured_Image( 'https://www.thenational.ae/image/policy:1.860575:1559198783/AR_1205_Sharjah_Mosque-40.jpg', $post_id );
		// add_post_meta($post_id, fgfdfgdfgdfg, 65464, true);
		// add_post_meta($post_id, 'META-KEY-2', 'META_VALUE-2', true);
		}
}
// end--This code check is there same title exist and insert post into custom post type. Also call Generate_Featured_Image function






// $post_id is Numeric ID... You can also get the ID with:
// wp_insert_post();
//this code Generate_Featured_Image from link
function Generate_Featured_Image( $image_url, $post_id  ){
    $upload_dir = wp_upload_dir();
    $image_data = file_get_contents($image_url);
    $filename = basename($image_url);
    if(wp_mkdir_p($upload_dir['path']))
      $file = $upload_dir['path'] . '/' . $filename;
    else
      $file = $upload_dir['basedir'] . '/' . $filename;
    file_put_contents($file, $image_data);

    $wp_filetype = wp_check_filetype($filename, null );
    $attachment = array(
        'post_mime_type' => $wp_filetype['type'],
        'post_title' => sanitize_file_name($filename),
        'post_content' => '',
        'post_status' => 'inherit'
    );
    $attach_id = wp_insert_attachment( $attachment, $file, $post_id );
    require_once(ABSPATH . 'wp-admin/includes/image.php');
    $attach_data = wp_generate_attachment_metadata( $attach_id, $file );
    $res1= wp_update_attachment_metadata( $attach_id, $attach_data );
    $res2= set_post_thumbnail( $post_id, $attach_id );
}
//end--this code Generate_Featured_Image from link


// function hcf_register_meta_boxes() {
//     add_meta_box( 'hcf-1', __( 'Custom Field No 1', 'hcf' ), 'hcf_display_callback', 'eventposts' );

//      add_meta_box( 'hcf-2', __( 'Custom Field No 2', 'hcf' ), 'hcf_display_callback2', 'eventposts' );
// }
// add_action( 'add_meta_boxes', 'hcf_register_meta_boxes' );

// /**
//  * Meta box display callback.
//  *
//  * @param WP_Post $post Current post object.
//  */
// function hcf_display_callback( $post ) {
//     echo "Hello Custom Field 1";
// }
         
// function hcf_display_callback2( $post ) {
//     echo "Hello Custom Field 2";
// }


// function echo_meta() {
// $my_meta = get_post_meta( $post->ID, 'hcf', true ); echo $my_meta["hcf"];
// }
// echo_meta();


//this code create an admin option to insert post in admin panel tool menu.

add_action( 'admin_action_wpse10500', 'wpse10500_admin_action' );
function wpse10500_admin_action()
{
    // Do your stuff here
    wp_redirect( $_SERVER['HTTP_REFERER'] );
    exit();
}
add_action( 'admin_menu', 'wpse10500_admin_menu' );
function wpse10500_admin_menu()
{
    add_management_page( 'WPSE 10500 Test page', 'Insert events as post', 'administrator', 'wpse10500', 'wpse10500_do_page' );
}
function wpse10500_do_page()
{
?>
    <form method="POST">
        <input type="hidden" name="action" value="wpse10500" />
        <!-- <input type="text" name="action2"/> -->
			<select name="trademarktm" >
			<option value='insert_yes'>YES</option>
			<option value="insert_no">NO</option>
			</select>
        <input type="submit" value="Do it!" />
    </form>

<?php
if($_POST['trademarktm'] == 'insert_yes') { 
	 easytuts_taxonomies_eventposts();
}
?>

<?php
}
//end--this code create an admin option to insert post in admin panel tool menu.

