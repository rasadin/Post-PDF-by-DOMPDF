;(function($) {
    
    
})(jQuery);